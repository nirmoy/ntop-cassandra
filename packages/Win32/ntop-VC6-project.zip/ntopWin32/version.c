char * version   = "3.4-pre1";
char * VERSION  = "3.4-pre1";
char * osName    = "i686-pc-linux-gnu";
char * author    = "Luca Deri <deri@ntop.org>";
char * configureDate = "ntop-factory.ntop.org";
char * buildDate = "24/12/09 19:20:53";
char * configure_parameters   = "";
char * host_system_type   = "Win32";
char * target_system_type   = "Win32";
char * compiler_cflags   = "";
char * include_path    = "";
char * system_libs    = "";
char * install_path   = "";
/*i18n*/
char * locale_dir   = "";
char * distro = "Windows";
char * release = "Win32";
