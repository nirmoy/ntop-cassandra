#include "ntop.h"

#ifndef WIN32
char * strcasestr (const char *phaystack, char *pneedle)
{
  const unsigned char *haystack, *needle;
  char bl, bu, cl, cu;

  haystack = (const unsigned char *) phaystack;
  needle = (const unsigned char *) pneedle;

  bl = _tolower (*needle);
  if (bl != '\0')
    {
      bu = _toupper (bl);
      haystack--;				/* possible ANSI violation */
      do
	{
	  cl = *++haystack;
	  if (cl == '\0')
	    goto ret0;
	}
      while ((cl != bl) && (cl != bu));

      cl = _tolower (*++needle);
      if (cl == '\0')
	goto foundneedle;
      cu = _toupper (cl);
      ++needle;
      goto jin;

      for (;;)
        {
          char a;
	  const unsigned char *rhaystack, *rneedle;

	  do
	    {
	      a = *++haystack;
	      if (a == '\0')
		goto ret0;
	      if ((a == bl) || (a == bu))
		break;
	      a = *++haystack;
	      if (a == '\0')
		goto ret0;
shloop:
	      ;
	    }
          while ((a != bl) && (a != bu));

jin:	  a = *++haystack;
	  if (a == '\0')
	    goto ret0;

	  if ((a != cl) && (a != cu))
	    goto shloop;

	  rhaystack = haystack-- + 1;
	  rneedle = needle;
	  a = _tolower (*rneedle);

	  if (_tolower (*rhaystack) == (int) a)
	    do
	      {
		if (a == '\0')
		  goto foundneedle;
		++rhaystack;
		a = _tolower (*++needle);
		if (_tolower (*rhaystack) != (int) a)
		  break;
		if (a == '\0')
		  goto foundneedle;
		++rhaystack;
		a = _tolower (*++needle);
	      }
	    while (_tolower (*rhaystack) == (int) a);

	  needle = rneedle;		/* took the register-poor approach */

	  if (a == '\0')
	    break;
        }
    }
foundneedle:
  return (char*) haystack;
ret0:
  return 0;
}
#endif